public interface IsLandVehicle extends IsVehicle{
    public int getNumWheels();
    public void setNumWheels(int numWheels);
    public void drive();
}
