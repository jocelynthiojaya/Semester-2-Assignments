public interface IsEmergency {
    public void soundSiren();
}
