public interface IsVehicle {
    public String getName();
    public void setName(String name);

    public int getMaxPassengers();
    public void setMaxPassengers(int maxPassengers);

    public int getMaxSpeed();
    public void setMaxSpeed(int maxSpeed);
}
