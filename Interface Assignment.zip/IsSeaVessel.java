public interface IsSeaVessel extends IsVehicle{
    public int getDisplacement();
    public void setDisplacement(int displacement);
    public void launch();
}
